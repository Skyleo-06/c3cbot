var exec = global.nodemodule["child_process"];
var pathtoffmpeg = global.nodemodule["ffmpeg-static"];
var axios = global.nodemodule["axios"];
var path = require("path");
var fs = require("fs");
var basedir = path.join(__dirname, "..", "SRI_storage");
ensureExists(basedir);

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var sri = function(type, data){
  if(data.args[1] != undefined && data.args[1] != ""){
    basedir = path.join(__dirname, "..", "SRI_storage", data.args[1]);
    try{
      console.log(!fs.existsSync(basedir));
      if(!fs.existsSync(basedir)){
        return{
          handler: "internal",
          data: `folder ${data.args[1]} not found!`
        }
      }
    }
    catch(err){ 
      console.log(err); 
    }
  }
  else {
    basedir = path.join(__dirname, "..", "SRI_storage");
  }
  fs.readdir(basedir, (err, files) => {
  	if(files.length != 0){
  		let ran = Math.floor(Math.random() * parseInt(files.length));
  		Promise.resolve({
  			attachment: fs.createReadStream(basedir + "/" + files[ran])
  		}).then(a =>  message.channel.send(a, res.data.data, (e, info)=>{
if(!e){
     setTimeout( function(){ 
 message.channel.send(info.messageID)
   }, 5000)
}
}, res.data.data));
  	}   
   });

}
		
module.exports = {
	sri
}