var fetch = global.nodemodule["node-fetch"];

var adbot = function adbot(type, data) {
	(async function () {
		var returntext = `Danh Sách lệnh img\n 👉girl \n 👉nude\n 👉cosplay\n 👉jimmy\n 👉sexy\nđợi update........\n"${global.config.commandPrefix}"+ Lệnh trên`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
    adbot: adbot
}